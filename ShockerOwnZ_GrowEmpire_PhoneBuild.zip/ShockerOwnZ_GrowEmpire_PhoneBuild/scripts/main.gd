extends Control

var cash := 500
var day := 1
var xp := 0
var level := 1
var rep := 0
var plant = null
var genetics = [
 {"name":"GG4 S1","cost":40,"days":8,"base":230},
 {"name":"Slurricane #7","cost":75,"days":10,"base":390},
 {"name":"RKS S1","cost":120,"days":12,"base":620},
 {"name":"Queen's Revenge S1","cost":180,"days":14,"base":950}
]
var status: Label
var plant_label: Label
var log_label: Label

func _ready():
    build_ui()
    refresh()

func build_ui():
    var bg = ColorRect.new()
    bg.color = Color("0b0b0d")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var root = VBoxContainer.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 22)
    root.add_theme_constant_override("separation", 14)
    add_child(root)
    var title = Label.new()
    title.text = "SHOCKER OWNZ\nGROW EMPIRE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 38)
    root.add_child(title)
    var motto = Label.new()
    motto.text = "PROJECT 0 • PRESERVE THE GENETICS"
    motto.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(motto)
    status = Label.new(); status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; root.add_child(status)
    plant_label = Label.new(); plant_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; plant_label.add_theme_font_size_override("font_size", 24); root.add_child(plant_label)
    for g in genetics:
        var b = Button.new(); b.text = "PLANT %s — $%d" % [g.name, g.cost]; b.pressed.connect(func(): plant_seed(g)); root.add_child(b)
    var advance = Button.new(); advance.text = "ADVANCE DAY"; advance.pressed.connect(advance_day); root.add_child(advance)
    var train = Button.new(); train.text = "TRAIN PLANT"; train.pressed.connect(train_plant); root.add_child(train)
    var harvest = Button.new(); harvest.text = "HARVEST"; harvest.pressed.connect(harvest_plant); root.add_child(harvest)
    log_label = Label.new(); log_label.text = "Grow • Hunt • Preserve • Breed • Build"; log_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; log_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; root.add_child(log_label)

func plant_seed(g):
    if plant != null: log_label.text = "Room occupied."; return
    if cash < g.cost: log_label.text = "Not enough cash."; return
    cash -= g.cost
    plant = {"name":g.name,"age":0,"days":g.days,"base":g.base,"quality":60,"trained":false}
    log_label.text = "%s planted." % g.name
    refresh()

func advance_day():
    day += 1
    if plant != null:
        plant.age += 1
        plant.quality = clampi(plant.quality + randi_range(-2,3), 35, 100)
    refresh()

func train_plant():
    if plant == null: log_label.text = "Plant something first."; return
    if plant.trained: log_label.text = "Already trained."; return
    plant.trained = true; plant.quality = clampi(plant.quality + 5,35,100); rep += 1
    log_label.text = "Training complete. Quality boosted."
    refresh()

func harvest_plant():
    if plant == null: log_label.text = "Nothing to harvest."; return
    if plant.age < plant.days: log_label.text = "Not ready yet."; return
    var grams = int((18.0 + plant.base / 28.0) * randf_range(0.9,1.1))
    var sale = int(grams * (4.0 + plant.quality / 18.0))
    cash += sale; xp += 75; rep += 5
    log_label.text = "Harvested %dg at Q%d • Sold for $%d" % [grams,plant.quality,sale]
    plant = null
    while xp >= level * 100:
        xp -= level * 100; level += 1
    refresh()

func refresh():
    status.text = "DAY %d   $%d   LVL %d   XP %d   REP %d" % [day,cash,level,xp,rep]
    if plant == null:
        plant_label.text = "ROOM 01 • EMPTY"
    else:
        var stage = "SEEDLING"
        if plant.age >= int(plant.days * 0.65): stage = "FLOWER"
        elif plant.age >= 2: stage = "VEG"
        if plant.age >= plant.days: stage = "HARVEST READY"
        plant_label.text = "%s\n%s • DAY %d/%d • Q%d" % [plant.name,stage,plant.age,plant.days,plant.quality]
